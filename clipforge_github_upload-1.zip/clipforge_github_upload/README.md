# ClipForge AI

A starter MVP for an AI-powered short-video clipping service.

## Project structure
- `backend/` FastAPI API, FFmpeg video processing, OpenAI transcription and clip selection.
- `frontend/` simple browser interface for uploading a video and downloading generated clips.

## Current MVP scope
- Upload a video file.
- Extract audio with FFmpeg.
- Transcribe speech with OpenAI Whisper (`whisper-1`).
- Ask an OpenAI chat model to select interesting moments.
- Export vertical MP4 clips with FFmpeg.
- Download generated clips from the API.

This is an early MVP, not a production-ready SaaS. It does not yet include customer accounts, payments, persistent cloud storage, background job queues, or burned-in captions.

## Deploy backend on Render
Use a Docker Web Service:
- Repository: `vatabrian9-commits/clipforge-ai`
- Branch: `main`
- Dockerfile Path: `backend/Dockerfile`
- Docker Context Directory: `backend`
- Environment variable: `OPENAI_API_KEY` = your secret OpenAI API key
- Optional: `OPENAI_MODEL` = `gpt-4o-mini`
- Health Check Path: `/health`

Do not upload `.env` files or API keys to GitHub.

After deployment, test `https://YOUR-SERVICE.onrender.com/health`.

## Run locally
Install Docker, then from the project root:

```bash
docker build -f backend/Dockerfile -t clipforge-api backend
docker run --rm -p 10000:10000 -e OPENAI_API_KEY=YOUR_KEY clipforge-api
```

Open `http://localhost:10000/health`.

## Connect frontend
Open `frontend/index.html` in a browser and enter your deployed backend URL in the API URL field.

## Important limitations
- The MVP processes one upload request synchronously. Large videos may exceed free hosting limits or request timeouts.
- Whisper has an audio upload size limit; long audio may need chunking in a later version.
- Generated files are stored on the service's temporary filesystem and may disappear after redeploy/restart.
- Only upload videos you own or have permission to process.
