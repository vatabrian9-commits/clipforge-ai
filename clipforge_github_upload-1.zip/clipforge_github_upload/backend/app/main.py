import json
import os
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path
from typing import List

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from openai import OpenAI

BASE_DIR = Path("/tmp/clipforge")
UPLOAD_DIR = BASE_DIR / "uploads"
OUTPUT_DIR = BASE_DIR / "outputs"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="ClipForge AI API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict to your frontend domain before public launch.
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/files", StaticFiles(directory=str(OUTPUT_DIR)), name="files")


@app.get("/")
def root():
    return {"service": "ClipForge AI API", "status": "running", "docs": "/docs"}


@app.get("/health")
def health():
    return {"status": "ok", "service": "clipforge-ai"}


def run_ffmpeg(args: List[str]):
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *args],
            check=True, capture_output=True, text=True
        )
    except subprocess.CalledProcessError as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Video processing failed: {exc.stderr[-1200:] if exc.stderr else 'FFmpeg error'}"
        )


@app.post("/api/clips/generate")
async def generate_clips(video: UploadFile = File(...), clip_count: int = Form(3)):
    if not video.filename:
        raise HTTPException(status_code=400, detail="Please choose a video file.")
    if clip_count < 1 or clip_count > 8:
        raise HTTPException(status_code=400, detail="clip_count must be between 1 and 8.")

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(status_code=503, detail="OPENAI_API_KEY is not configured on the server.")

    job_id = uuid.uuid4().hex[:12]
    job_dir = BASE_DIR / job_id
    job_dir.mkdir(parents=True, exist_ok=True)
    suffix = Path(video.filename).suffix.lower() or ".mp4"
    input_path = job_dir / f"source{suffix}"
    audio_path = job_dir / "audio.mp3"

    try:
        size = 0
        with input_path.open("wb") as out:
            while True:
                chunk = await video.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > 250 * 1024 * 1024:
                    raise HTTPException(status_code=413, detail="Video exceeds the 250 MB MVP upload limit.")
                out.write(chunk)

        # Extract compressed audio for transcription.
        run_ffmpeg(["-i", str(input_path), "-vn", "-ac", "1", "-ar", "16000",
                    "-b:a", "48k", str(audio_path)])

        if audio_path.stat().st_size > 24 * 1024 * 1024:
            raise HTTPException(
                status_code=413,
                detail="Extracted audio is too large for this MVP's single transcription request. Use a shorter video."
            )

        client = OpenAI(api_key=api_key)
        with audio_path.open("rb") as audio_file:
            transcript = client.audio.transcriptions.create(
                model="whisper-1",
                file=audio_file,
                response_format="verbose_json",
                timestamp_granularities=["segment"]
            )

        segments = getattr(transcript, "segments", None) or []
        transcript_text = getattr(transcript, "text", "") or ""
        if not transcript_text.strip():
            raise HTTPException(status_code=422, detail="No speech was detected in this video.")

        # Provide timestamped transcript when available, otherwise ask model to infer from text.
        timed_text = []
        for seg in segments:
            timed_text.append({
                "start": float(getattr(seg, "start", 0)),
                "end": float(getattr(seg, "end", 0)),
                "text": getattr(seg, "text", "")
            })

        model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        prompt = (
            "Choose up to " + str(clip_count) +
            " compelling short-video moments from this transcript. "
            "Return ONLY JSON with key clips containing objects with start, end, title, reason. "
            "Times must be seconds, start >= 0, end > start, and each clip should be 15 to 60 seconds "
            "where possible. Prefer self-contained moments with a strong hook and payoff. "
            "Do not invent transcript content. Transcript: " +
            json.dumps(timed_text if timed_text else transcript_text, ensure_ascii=False)
        )
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are an expert short-form video editor. Output valid JSON only."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"},
            temperature=0.3
        )
        data = json.loads(response.choices[0].message.content or "{}")
        proposed = data.get("clips", [])
        if not proposed:
            raise HTTPException(status_code=422, detail="AI could not identify suitable clips.")

        # Read source duration.
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(input_path)],
            capture_output=True, text=True, check=True
        )
        duration = float(probe.stdout.strip() or "0")

        results = []
        for index, item in enumerate(proposed[:clip_count], start=1):
            start = max(0.0, float(item.get("start", 0)))
            end = min(duration, float(item.get("end", start + 30)))
            if end <= start:
                continue
            # Bound clips to a useful range for this MVP.
            if end - start > 60:
                end = start + 60
            if end - start < 5:
                continue
            filename = f"{job_id}_clip_{index}.mp4"
            output_path = OUTPUT_DIR / filename
            run_ffmpeg([
                "-ss", str(start), "-i", str(input_path), "-t", str(end - start),
                "-vf", "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
                "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart",
                str(output_path)
            ])
            results.append({
                "title": str(item.get("title", f"Clip {index}"))[:100],
                "reason": str(item.get("reason", ""))[:300],
                "start": round(start, 2),
                "end": round(end, 2),
                "duration": round(end - start, 2),
                "download_url": f"/files/{filename}"
            })

        if not results:
            raise HTTPException(status_code=422, detail="No valid clips could be exported.")
        return {"job_id": job_id, "transcript": transcript_text, "clips": results}

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Clip generation failed: {str(exc)[:500]}")
    finally:
        await video.close()
